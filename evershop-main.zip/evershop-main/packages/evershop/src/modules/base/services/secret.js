const { v4: uuidv4 } = require('uuid');

const secret = uuidv4();
module.exports = secret;
